import re as re
import sys
import os

token = ""
tokenlist_Num = 0
tokenlist = []
finallist = []
c0 = ["int", "void"]
c1 = ["+", "-", "<=", "<", ">", ">=", "==", "!=", ",", ")", "]", ";"]
c2 = ["<=", "<", ">", ">=", "==", "!=", ",", ")", "]", ";"]
c3 = ["ID:", "INT:"]
c4 = ["<=", "<", ">", ">=", "==", "!="]
c5 = [",", ")", "]", ";"]
c6 = ["[", "*", "/", "+", "-"]
c7 = ["*", "/", "+", "-", "<=", "<", ">", ">=", "==", "!="]


class Token(object):

    def __init__(self, type, value, position):
        self.type = type
        self.value = value
        self.position = position

    def __str__(self):
        return '%s %s' % (self.type, self.value)


class Lex(object):

    def __init__(self, rules, ws=True):

        regular_expresions_parts = []
        self.group_type = {}
        index = 1

        for regular_expresions, type in rules:
            regex = 'GROUP%s' % index
            regular_expresions_parts.append('(?P<%s>%s)' % (regex, regular_expresions))
            self.group_type[regex] = type
            index = index + 1
        self.skip = re.compile('\S')
        self.regular_expresions = re.compile('|'.join(regular_expresions_parts))
        self.ws = ws

    def intro(self, buff):
        self.position = 0
        self.buff = buff

    def token(self):
        if self.position >= len(self.buff):
            return None
        else:
            if self.ws:
                m = self.skip.search(self.buff, self.position)
                if m:
                    self.position = m.start()
                else:
                    return None

            m = self.regular_expresions.match(self.buff, self.position)
            if m:
                regex = m.lastgroup
                till = self.group_type[regex]
                finish = Token(till, m.group(regex), self.position)
                self.position = m.end()
                return finish

    def tokens(self):
        while 1:
            t = self.token()
            if t is None:
                break
            yield t


if __name__ == '__main__':
    rules = [
        ('(?<![a-zA-Z0-9])(else|if|int|return|void|while|float)(?![a-zA-Z0-9])', ''),
        ('[a-z]+', ''),
        ('[0-9]+(\.[0-9]+)?(E(\+|-)?[0-9]+)?', ''),
        ('\/\*|\*\/|\+|-|\*|//|/|<=|<|>=|>|==|!=|=|;|,|\(|\)|\{|\}|\[|\]', ''),
        ('!|@|_', ''),
    ]

    lx = Lex(rules, ws=True)

    content = ""
    test = ""
    after = ""


def scanner():
    try:

        # with open(sys.argv[1], 'r') as file:
        with open("test.txt", 'r') as file:
            content = file.read()
            test = re.sub((r'\n'), '', content)
            after = re.sub(r'(?://[^\n]*|/\*(?:(?!\*/).)*\*/)', '', test)

        lx.intro(after)

        for x in lx.tokens():
            tokenlist.append((str(x)).strip())

        length = len(tokenlist)
        i = 0

        with open("tokens.txt", "w") as f1:
            while i < length:
                if tokenlist[i] in ["else", "if", "int", "return", "void", "while", "float"]:
                    f1.writelines(tokenlist[i] + "\n")
                    i += 1
                else:
                    if re.match(r'[a-z]+', tokenlist[i]):
                        f1.writelines("ID " + tokenlist[i] + "\n")
                        i += 1
                    else:
                        if re.match(r'[0-9]+', tokenlist[i]):
                            f1.writelines("INT " + tokenlist[i] + "\n")
                            i += 1
                        else:
                            f1.writelines(tokenlist[i] + "\n")
                            i += 1


    except IOError:
        print("Error: File does not appear to exist.")




    with open('tokens.txt', 'r') as f:
        lines = f.read().split('\n')
        if(lines in ["else","if","int","return","void","while","float"]):
            finallist.append(lines)
        else:
            if(re.match(r'[a-z]+', lines)):
                finallist.append(('ID', lines))
            else:
                if re.match(r'[0-9]+', lines):
                    finallist.append(('NUM', tokenlist[i]))
                else:
                    finallist.append(lines)


    print(finallist)

scanner()

global i
i = 0
global x
x = 0
sym_table = [{'sym_name': None, 'sym_val': None, 'sym_attr': None}]

token_list_value = []
token_list_type = []

try:
    with open("tokens.txt", "r") as f2:
        tokens = f2.readlines()
        for token in tokens:
            if(len(token.split(" ")) == 2):
                token_value = token.split(" ")[1]
                token_type = token.split(" ")[0]
            else:
                token_value = token
                token_type = token
            token_value = token_value.strip()
            token_type = token_type.strip()
            token_list_value.append(token_value)
            token_list_type.append(token_type)
    token_list_value.append("$")
    token_list_type.append("$")
except:
    exit()

def exitProgram():
    global i
    print("REJECT")
    exit()


def program():
    global i
    declaration()
    declarationList()


def declaration():
    global i
    if token_list_value[i] == "int":
        i += 1
        if token_list_type[i] == "ID:":
            i += 1
            declarationPrime()
    elif token_list_value[i] == "void":
        i += 1
        if token_list_type[i] == "ID:":
            i += 1
            declarationPrime()
        else:
            exitProgram()
    else:
        exitProgram()


def declarationPrime():
    global i
    if token_list_value[i] == "(":
        funDeclaration()
    elif token_list_value[i] in [";", "["]:
        varDeclaration()
    else:
        exitProgram()


def declarationList():
    global i
    if token_list_value[i] in c0:
        declaration()
        declarationList()
    elif token_list_value[i] in "$":
        print("ACCEPT")
        exit()
    else:
        exitProgram()


def funDeclaration():
    global i
    if token_list_value[i] == "(":
        i += 1
        params()
        if token_list_value[i] == ")":
            i += 1
            compoundStmt()
    else:
        exitProgram()


def varDeclaration():
    global i
    if token_list_value[i] == ";":
        i += 1
    elif token_list_value[i] == "[":
        i += 1
        if token_list_type[i] == "INT:":
            i += 1
        if token_list_value[i] == "]":
            i += 1
        if token_list_value[i] == ";":
            i += 1
    else:
        exitProgram()


def params():
    global i
    if token_list_value[i] == "void":
        i += 1
        paramsPrime()
    elif token_list_value[i] == "int":
        i += 1
        paramsPrime()
    else:
        exitProgram()


def paramsPrime():
    global i
    if token_list_type[i] == "ID:":
        i += 1
        param()
        paramList()
    elif token_list_value[i] == ")":
        return
    else:
        exitProgram()


def paramList():
    global i
    if token_list_value[i] == ",":
        i += 1
        paramListPrime()
    elif token_list_value[i] == ")":
        return
    else:
        exitProgram()


def paramListPrime():
    global i
    if token_list_value[i] == "int":
        # consume "int"
        i += 1
        if token_list_type[i] == "ID:":
            # consume ID
            i += 1
        else:
            exitProgram()
        param()
        paramList()
    elif token_list_value[i] == "void":
        # consume void
        i += 1
        if token_list_type[i] == "ID:":
            # consume ID
            i += 1
        else:
            exitProgram()
        param()
        paramList()
    else:
        exitProgram()


def param():
    global i
    if token_list_value[i] == "[":
        i += 1
        if token_list_value[i] == "]":
            i += 1
        else:
            exitProgram()
    elif token_list_value[i] in [",", ")"]:
        return
    else:
        exitProgram()


def compoundStmt():
    global i
    if token_list_value[i] == "{":
        i += 1
        localDeclarations()
        statementList()
        if token_list_value[i] == "}":
            i += 1
    else:
        exitProgram()


def localDeclarations():
    global i
    if token_list_value[i] == "int":
        i += 1
        if token_list_type[i] == "ID:":
            i += 1
            varDeclaration()
            localDeclarations()
    elif token_list_value[i] == "void":
        i += 1
        if token_list_type[i] == "ID:":
            i += 1
            varDeclaration()
            localDeclarations()
    elif token_list_value[i] in [";", "(", "if", "return", "{", "while", "}"] or token_list_type[i] in c3:
        return
    else:
        exitProgram()


def statementList():
    global i
    if token_list_value[i] in [";", "(", "if", "return", "{", "while"] or token_list_type[i] in c3:
        statement()
        statementList()
    elif token_list_value[i] == "}":
        return
    else:
        exitProgram()


def statement():
    global i
    if token_list_value[i] in [";", "("] or token_list_type[i] in c3:
        expressionStmt()
    elif token_list_value[i] == "{":
        compoundStmt()
    elif token_list_value[i] == "if":
        selectionStmt()
    elif token_list_value[i] == "while":
        iterationStmt()
    elif token_list_value[i] == "return":
        returnStmt()
    else:
        exitProgram()


def expressionStmt():
    global i
    if token_list_value[i] == "(" or token_list_type[i] in c3:
        expression()
        if token_list_value[i] == ";":
            i += 1
        else:
            exitProgram()
    elif token_list_value[i] == ";":
        i += 1
    else:
        exitProgram()


def selectionStmt():
    global i
    if token_list_value[i] == "if":
        i += 1
        if token_list_value[i] == "(":
            i += 1
            expression()
        if token_list_value[i] == ")":
            i += 1
            statement()
            selectionStmtPrime()
    else:
        exitProgram()


def selectionStmtPrime():
    global i
    if token_list_value[i] == "else":
        i += 1
        statement()
    elif token_list_value[i] in ["else", ";", "(", "if", "return", "{", "while", "}"] or token_list_type[i] in c3:
        return
    else:
        exitProgram()


def iterationStmt():
    global i
    if token_list_value[i] == "while":
        i += 1
        if token_list_value[i] == "(":
            i += 1
            expression()
        if token_list_value[i] == ")":
            i += 1
            statement()
    else:
        exitProgram()


def returnStmt():
    global i
    if token_list_value[i] == "return":
        i += 1
        returnStmtPrime()
    else:
        exitProgram()


def returnStmtPrime():
    global i
    if token_list_value[i] == ";":
        i += 1
    elif token_list_value[i] == "(" or token_list_type[i] in c3:
        expression()
        i += 1
    else:
        exitProgram()


def expression():
    global i
    if token_list_type[i] == "ID:":
        i += 1
        expressionPrime()
        if token_list_value[i] in c5:
            return
    elif token_list_value[i] == "(" or token_list_type[i] == "INT:":
        simpleExpression()
    else:
        exitProgram()


def expressionPrime():
    global i
    if token_list_value[i] in ["[", "=", "*", "/", "<=", "<", ">", ">=", "==", "!=", "+", "-"]:
        var()
        expressionPrimePrime()
    elif token_list_value[i] == "(":
        factorPrime()
        term()
        additiveExpressionPrime()
        simpleExpressionPrime()
    elif token_list_value[i] in c5:
        return
    else:
        exitProgram()


def expressionPrimePrime():
    global i
    if token_list_value[i] == "=":
        i += 1
        expression()
    elif token_list_value[i] in c7:
        term()
        additiveExpressionPrime()
        simpleExpressionPrime()
    elif token_list_value[i] in c2:
        return
    else:
        exitProgram()


def var():
    global i
    if token_list_value[i] == "[":
        i += 1
        expression()
        i += 1
    elif token_list_value[i] in c7 or token_list_value[i] in c5:
        return
    else:
        exitProgram()


def simpleExpression():
    global i
    additiveExpression()
    simpleExpressionPrime()


def simpleExpressionPrime():
    global i
    if token_list_value[i] in c4:
        relop()
        simpleExpressionPrimePrime()
    elif token_list_value[i] in c5:
        return
    else:
        exitProgram()


def simpleExpressionPrimePrime():
    global i
    if token_list_value[i] == "(" or token_list_type[i] == "INT:":
        additiveExpression()
    elif token_list_type[i] == "ID:":
        i += 1
        simpleExpressionPrimePrimePrime()
    else:
        exitProgram()


def simpleExpressionPrimePrimePrime():
    global i
    if token_list_value[i] == "(":
        factorPrime()
        term()
        additiveExpressionPrime()
    elif token_list_value[i] in c6:
        var()
        term()
        additiveExpressionPrime()
    elif token_list_value[i] in c5:
        return
    else:
        exitProgram()


def relop():
    global i
    if token_list_value[i] in c4:
        i += 1
    else:
        exitProgram()


def additiveExpression():
    global i
    if token_list_value[i] == "(" or token_list_type[i] == "INT:":
        factor()
        term()
        additiveExpressionPrime()
    else:
        exitProgram()


def additiveExpressionPrime():
    global i
    if token_list_value[i] in ["+", "-"]:
        addop()
        additiveExpressionPrimePrime()
    elif token_list_value[i] in c2:
        return
    else:
        exitProgram()


def additiveExpressionPrimePrime():
    global i
    if token_list_value[i] == "(" or token_list_type[i] == "INT:":
        factor()
        term()
        additiveExpressionPrime()
    elif token_list_type[i] == "ID:":
        i += 1
        additiveExpressionPrimePrimePrime()
    else:
        exitProgram()


def additiveExpressionPrimePrimePrime():
    global i
    if token_list_value[i] == "(":
        factorPrime()
        term()
        additiveExpressionPrime()
    elif token_list_value[i] in c6:
        var()
        term()
        additiveExpressionPrime()
    elif token_list_value[i] in c2:
        return
    else:
        exitProgram()


def addop():
    global i
    if token_list_value[i] == "+":
        i += 1
    elif token_list_value[i] == "-":
        i += 1
    else:
        exitProgram()


def term():
    global i
    if token_list_value[i] in ["*", "/"]:
        mulop()
        termPrime()
    elif token_list_value[i] in c1:
        return
    else:
        exitProgram()


def termPrime():
    global i
    if token_list_value[i] == "(" or token_list_type[i] == "INT:":
        factor()
        term()
    elif token_list_type[i] == "ID:":
        i += 1
        termPrimePrime()
    else:
        exitProgram()


def termPrimePrime():
    global i
    if token_list_value[i] == "(":
        factorPrime()
        term()
    elif token_list_value[i] in ["[", "*", "/"]:
        var()
        term()
    elif token_list_value in c1:
        return
    else:
        exitProgram()


def mulop():
    global i
    if token_list_value[i] == "*":
        i += 1
    elif token_list_value[i] == "/":
        i += 1
    else:
        exitProgram()


def factor():
    global i
    if token_list_value[i] == "(":
        i += 1
        expression()
        if token_list_value[i] == ")":
            i += 1
    elif token_list_type[i] == "INT:":
        i += 1
    else:
        exitProgram()


def factorPrime():
    global i
    if token_list_value[i] == "(":
        i += 1
        args()
        if token_list_value[i] == ")":
            i += 1
    else:
        exitProgram()


def args():
    global i
    if token_list_value[i] == "(" or token_list_type[i] in c3:
        expression()
        argList()
    elif token_list_value[i] == ")":
        return
    else:
        exitProgram()


def argList():
    global i
    if token_list_value[i] == ",":
        i += 1
        expression()
        argList()
    elif token_list_value[i] == ")":
        return
    else:
        exitProgram()


program()
