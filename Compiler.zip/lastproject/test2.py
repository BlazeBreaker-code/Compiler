import re
import sys

token = ""
tokenlist = []
tokenlistNum = 0

c0 = ["int", "void"]
c1 = ["ID", "NUM", "("]
c2 = ['/', '<', '<=', '==', '>', '>=', '!=', '*', '+', '-']
c4 = ["(", ";", "if", "return", "while", "{"]
c5 = ['==', '>', '>=', '!=', '<', '<=']
string = "{:10s} {:10s} {:10s} {:10s} {}"

kw = re.compile(r'^else|if|int|return|void|while')
id = re.compile(r'^[a-zA-Z]+')
num = re.compile(r'^[0-9]+')
op = re.compile(r'^(\!=)|\==|\+|\-|\*|\/|(\<=)|\<|(\>=)|\>|\=|\;|\,|\(|\)|\[|\]|\{|\}')
inputlist = []


class Token(object):

    def __init__(self, type, value, position):
        self.type = type
        self.value = value
        self.position = position

    def __str__(self):
        return '%s %s' % (self.type, self.value)


def tokenizer(inputlist):
    for item in inputlist:
        s = item.strip()
        i = 0
        while i < s.__len__():
            if s[i].isspace():
                i += 1
                continue
            elif kw.search(s[i:]):
                tokenlist.append(kw.search(s[i:])[0])
                i += kw.search(s[i:])[0].__len__()
            elif id.search(s[i:]):
                tokenlist.append(('ID', id.search(s[i:])[0]))
                i += id.search(s[i:])[0].__len__()
            elif num.search(s[i:]):
                tokenlist.append(("NUM", num.search(s[i:])[0]))
                i += num.search(s[i:])[0].__len__()
            elif op.search(s[i:]):
                tokenlist.append(op.search(s[i:])[0])
                i += op.search(s[i:])[0].__len__()
            else:
                i += s[i:][0].__len__()


class Lex(object):

    def __init__(self, rules, ws=True):

        regular_expresions_parts = []
        self.group_type = {}
        index = 1

        for regular_expresions, type in rules:
            regex = 'GROUP%s' % index
            regular_expresions_parts.append('(?P<%s>%s)' % (regex, regular_expresions))
            self.group_type[regex] = type
            index = index + 1
        self.skip = re.compile('\S')
        self.regular_expresions = re.compile('|'.join(regular_expresions_parts))
        self.ws = ws

    def intro(self, buff):
        self.position = 0
        self.buff = buff

    def token(self):
        if self.position >= len(self.buff):
            return None
        else:
            if self.ws:
                m = self.skip.search(self.buff, self.position)
                if m:
                    self.position = m.start()
                else:
                    return None

            m = self.regular_expresions.match(self.buff, self.position)
            if m:
                regex = m.lastgroup
                till = self.group_type[regex]
                finish = Token(till, m.group(regex), self.position)
                self.position = m.end()
                return finish

    def tokens(self):
        while 1:
            t = self.token()
            if t is None:
                break
            yield t


if __name__ == '__main__':
    rules = [
        ('(?<![a-zA-Z0-9])(else|if|int|return|void|while|float)(?![a-zA-Z0-9])', ''),
        ('[a-z]+', ''),
        ('[0-9]+(\.[0-9]+)?(E(\+|-)?[0-9]+)?', ''),
        ('\/\*|\*\/|\+|-|\*|//|/|<=|<|>=|>|==|!=|=|;|,|\(|\)|\{|\}|\[|\]', ''),
        ('!|@|_', ''),
    ]

    lx = Lex(rules, ws=True)

    content = ""
    test = ""
    after = ""

try:
    with open('test.txt', 'r') as file:
        content = file.read()
        for line in content:
            test = re.sub((r'\n'), '', content)
            after = re.sub(r'(?://[^\n]*|/\*(?:(?!\*/).)*\*/)', '', test)

    lx.intro(after)

    for x in lx.tokens():
        inputlist.append((str(x)).strip())

    tokens = tokenizer(inputlist)
    tokenlist.append("$")
    tokenlist.append("&")

except IOError:
    print("Error: File does not appear to exist.")

var_tab = {}
func_tab = []

temporary = ['t0', 't1', 't2', 't3', 't4', 't5', 't6', 't7', 't8', 't9', 't10', 't11' 't12', 't13', 't14', 't15', 't16',
             't17', 't18', 't19']

ts = 0
instr = 1


def is_ID(token):
    return isinstance(token, tuple) and token[0] == 'ID'


def is_NUM(token):
    return isinstance(token, tuple) and token[0] == 'NUM'


def generator(tokenlist):
    global token, token_list
    token = tokenlist[tokenlistNum]
    token_list = tokenlist
    try:
        program()
    except ValueError:
        print("REJECT")
        print("var_tab: ", var_tab, "\nfunc_tab: ", func_tab)


def update():
    global token, tokenlistNum
    token = token_list[tokenlistNum]


def matchID(check):
    global tokenlistNum, n
    if token[0] == check:
        n = token[1]
        tokenlistNum = tokenlistNum + 1
        update()


def matchNUM(check):
    global tokenlistNum
    if token[0] == check:
        tokenlistNum += 1
        update()


def match(check):
    global tokenlistNum
    if token == check:
        tokenlistNum = tokenlistNum + 1
        update()


def program():
    declaration_list()


def declaration_list():
    if token in c0:
        declaration()
        declaration_list()


def declaration():
    n = ''
    if token in c0:
        t = type_specifier()
        if is_ID(token):
            n = token[1]
            matchID("ID")
        if (token == "(") or (token == ";") or (token == "["):
            start(n, t)


def start(n, t):
    global instr
    if (token == ";") or (token == "["):
        arrayAlloc(n, t)
    if token == "(":
        match("(")
        if token in c0:
            param_items = params()
            func_tab.append((n, t, param_items))
            print(string.format(str(instr), 'func', n, t, len(param_items)))
            instr += 1
            for item in param_items:
                if item == 'void':
                    break
                print(string.format(str(instr), 'param', " ", " ", item))
                instr += 1
            for item in param_items:
                if item == 'void':
                    break
                print(string.format(str(instr), 'alloc', '4', " ", item))
                instr += 1
        match(")")
        if token == "{":
            compound_stmt(n, t)
            print(string.format(str(instr), "end", "func", func_tab[-1][0], " "))


def var_declaration(n, t):
    if c0:
        t = type_specifier()
        if is_ID(token):
            n = token[1]
            matchID("ID")
        if token == ";" or token == "[":
            arrayAlloc(n, t)


def arrayAlloc(n, t):
    global instr
    save = ''
    if token == ";":
        match(";")
        var_tab[n] = t
        print('{:10s} {:10s} {:10s} {:10s} {:10s}'.format(str(instr), "alloc", "4", "          ", n))
        instr += 1
    else:
        match("[")
        if is_NUM(token):
            save = token
            matchNUM("NUM")
        match("]")
        match(";")
        var_tab[n] = "array"
        arr_size = 4 * int(save[1])
        print('{:10s} {:10s} {:10s} {:10s} {:10s}'.format(str(instr), "alloc", str(arr_size), "          ", n))
        instr += 1


def type_specifier():
    if token == "int":
        match("int")
        t = "int"
    if token == "void":
        match("void")
        t = "void"
    return t


def params():
    param_items = []
    if token == "int":
        temp = token
        match("int")
        if is_ID(token):
            list(param_items, temp)
    elif token == "void":
        temp = token
        match("void")
        param_items.append(temp)
    return param_items


def list(param_items, temp):
    if is_ID(token):
        param_name = token[1]
        var_tab[param_name] = temp
        matchID("ID")
        if token in ["["]:
            match_2()
            param_items.append(param_name)
        else:
            param_items.append(param_name)
        if token in [","]:
            match_0(param_items)


def param(param_items):
    if token in c0:
        t = type_specifier()
        if is_ID(token):
            param_name = token[1]
            var_tab[param_name] = t
            matchID("ID")
        if token == "[":
            match_2()
        param_items.append(param_name)


def compound_stmt(n, t):
    match("{")
    if token == "int" or token == "void":
        local_declarations(n, t)
    if token in c4 or is_ID(token) or is_NUM(token):
        statement_list()
    match("}")


def local_declarations(n, t):
    if token in c0:
        match_3(n, t)


def statement_list():
    if token in c4 or is_ID(token) or is_NUM(token):
        statement()
        if token in c4 or is_ID(token) or is_NUM(token):
            statement_list()


def statement():
    n = ' '
    t = ' '
    if token in ["(", ";"] or is_ID(token) or is_NUM(token):
        expression_stmt()
    elif token in ["{"]:
        print("{:10s} {:10s}".format(str(instr), "block"))
        compound_stmt(n, t)
        print("{:10s} {:10s} {:10s}".format(str(instr), "end", "block"))
    elif token in ["if"]:
        selection_stmt()
    elif token in ["while"]:
        iteration_stmt()
    elif token in ["return"]:
        return_stmt()


def expression_stmt():
    if token in ["("] or is_ID(token) or is_NUM(token):
        expression()
        match(";")
    else:
        match(";")


def selection_stmt():
    match("if")
    match("(")
    if token in ["("] or is_ID(token) or is_NUM(token):
        expression()
        match(")")
        if token in c4 or is_ID(token) or is_NUM(token):
            statement()
            if token in ["else"]:
                match_1()


def iteration_stmt():
    match("while")
    match("(")
    if token in ["("] or is_ID(token) or is_NUM(token):
        expression()
        match(")")
        if token in c4 or is_ID(token) or is_NUM(token):
            statement()


def return_stmt():
    global instr
    match("return")
    if token in ['(', ';'] or is_ID(token) or is_NUM(token):
        operand2 = match_4()
        print(string.format(str(instr), "return", " ", " ", operand2))
        instr += 1


def expression():
    global ts, instr
    if is_ID(token):
        is_array = False
        if var_tab[token[1]] == 'array':
            is_array = True
        operand1 = token[1]
        matchID("ID")
        if token in ["["] and is_array == True:
            match("[")
            if token in ["("] or c1:
                expression()
            match("]")
        if token in ['!=', '*', '+', '-', '/', '<', '<=', '=', '==', '>', '>=', '(']:
            innerop = True
            while innerop:
                operation, operand2 = match_5()
                if operation == 'assign':
                    print(string.format(str(instr), operation, operand1, " ", operand2))
                    instr += 1
                elif operation in ['bre', 'brge', 'brg', 'brne', 'brle', 'brl']:
                    print(string.format(str(instr), 'comp', operand1, operand2, temporary[ts]))
                    ts += 1
                    instr += 1
                    print(string.format(str(instr), operation, operand1, operand2, " "))
                    instr += 1
                else:
                    print(string.format(str(instr), operation, operand1, operand2, temporary[ts]))
                    operand2 = temporary[ts]
                    ts += 1
                    instr += 1
                if not token in ['!=', '*', '+', '-', '/', '<', '<=', '=', '==', '>', '>=', '(']:
                    innerop = False
            return operation, operand2
        else:
            operand2 = operand1
            operation = ' '
            return operation, operand2
    elif token in ["("]:
        match("(")
        if token in ["("] or is_ID(token) or is_NUM(token):
            operation, operand2 = expression()
            match(")")
            return operand2
        if token in ['!=', '*', '+', '-', '/', '<', '<=', '==', '>', '>=']:
            operation, operand2 = match_7()
            return operand2
    elif is_NUM(token):
        operand1 = token[1]
        matchNUM("NUM")
        if token in ['!=', '*', '+', '-', '/', '<', '<=', '==', '>', '>=']:
            operation, operand2 = match_7()
            if operation == 'assign':
                print(string.format(str(instr), operation, operand1, " ", operand2))
                instr += 1
            elif operation in ['bre', 'brge', 'brg', 'brne', 'brle', 'brl']:
                print(string.format(str(instr), 'comp', operand1, operand2, temporary[ts]))
                ts += 1
                instr += 1
                print(string.format(str(instr), operation, operand1, operand2, " "))
                instr += 1
            else:
                print(string.format(str(instr), operation, operand1, operand2, temporary[ts]))
                operand2 = temporary[ts]
                ts += 1
                instr += 1
            return operation, operand2
        else:
            operand2 = operand1
            operation = ' '
            return operation, operand2


def relop():
    if token in ["!="]:
        operation = 'bre'
        match("!=")
    elif token in ["=="]:
        operation = 'brne'
        match("==")
    elif token in ["<="]:
        operation = 'brg'
        match("<=")
    elif token in ["<"]:
        operation = 'brge'
        match("<")
    elif token in [">"]:
        operation = 'brle'
        match(">")
    else:
        operation = 'brl'
        match(">=")
    return operation


def additive_expression():
    global ts, instr
    if token in ["("] or is_ID(token) or is_NUM(token):
        operand2 = term()
        if token in ["-", "+"]:
            operand, operand3 = match_10()
            print(string.format(str(instr), operand, operand2, operand3, temporary[ts]))
            operand3 = temporary[ts]
            ts += 1
            instr += 1
            return operand3
        return operand2


def addop():
    if token in ["+"]:
        operation = "add"
        match("+")
        return operation
    if token in ["-"]:
        operation = 'sub'
        match("-")
        return operation


def term():
    global ts, instr
    if token in ["("] or is_ID(token) or is_NUM(token):
        operand2 = factor()
        if token in ["*", "/"]:
            operation, operand3 = match_11()
            print(string.format(str(instr), operation, operand2, operand3, temporary[ts]))
            operand3 = temporary[ts]
            ts += 1
            instr += 1
            return operand3
        return operand2


def mulop():
    if token in ["*"]:
        operation = "mult"
        match("*")
        return operation
    else:
        if token in ["/"]:
            operation = "div"
        match("/")
        return operation


def factor():
    if token in ["("]:
        match("(")
        if token in ["("] or is_ID(token) or is_NUM(token):
            operation, operand2 = expression()
        match(")")
        return operand2
    elif is_ID(token):
        operand2 = token[1]
        matchID("ID")
        match_12()
        return operand2
    else:
        if is_NUM(token):
            operand2 = token[1]
            matchNUM("NUM")
            return operand2


def call():
    if is_ID(token):
        matchID("ID")
    match("(")
    args()
    match(")")


def args():
    if token in ["("] or is_ID(token) or is_NUM(token):
        arg_list()


def arg_list():
    if token in ["("] or is_ID(token) or is_NUM(token):
        expression()
    if token in [","]:
        match_13()


def match_0(param_items):
    match(",")
    if token in c0:
        param(param_items)
        if token == ",":
            match_0(param_items)


def match_1():
    match("else")
    if token in c4 or is_ID(token) or is_NUM(token):
        statement()


def match_2():
    match("[")
    match("]")
    if token == "[":
        match_2()


def match_3(n, t):
    if token in c0:
        var_declaration(n, t)
        if token in c0:
            match_3(n, t)


def match_4():
    if token in ["("] or is_ID(token) or is_NUM(token):
        operand2 = expression()
        match(";")
        return operand2
    else:
        match(";")


def match_5():
    if token in ['!=', '*', '+', '-', '/', '<', '<=', '=', '==', '>', '>=']:
        if token == '=':
            operation = 'assign'
            operation1, operand2 = match_6()
            if not (operation1 == None or operand2 == None):
                return operation, operand2
            else:
                return " ", " "
        operation, operand2 = match_6()
        return operation, operand2
    elif token in ["("]:
        match("(")
        if token in ["("] or is_ID(token) or is_NUM(token):
            args()
        match(")")
        if token in c2:
            operation, operand2 = match_7()
            return operation, operand2


def match_6():
    if token in ["="]:
        match("=")
        if token in ["("] or is_ID(token) or is_NUM(token):
            operation, operand2 = expression()
            return operation, operand2
    else:
        if token in c2:
            operation, operand2 = match_7()
            return operation, operand2


def match_7():
    if token in ["*", "/"]:
        operation, operand2 = match_11()
        return operation, operand2
    elif token in ["+", "-"]:
        operation, operand2 = match_10()
        return operation, operand2
    elif token in c5:
        operation, operand2 = match_9()
        return operation, operand2


def match_8():
    if token in ["["]:
        match("[")
        if token in ["("] or is_ID(token) or is_NUM(token):
            lhs = expression()
        match("]")
        return lhs


def match_9():
    if token in c5:
        operation = relop()
        if token in ["("] or is_ID(token) or is_NUM(token):
            operand2 = additive_expression()
        return operation, operand2


def match_10():
    global instr, ts
    if token in ["+", "-"]:
        operation = addop()
        if token in ["("] or is_ID(token) or is_NUM(token):
            operand2 = term()
            if token in ["-", "+"]:
                operand, operand3 = match_10()
                print(string.format(str(instr), operand, operand2, operand3, temporary[ts]))
                operand3 = temporary[ts]
                ts += 1
                instr += 1
                return operation, operand3
            return operation, operand2


def match_11():
    global instr, ts
    if token in ["*", "/"]:
        operation = mulop()
        if token in ["("] or is_ID(token) or is_NUM(token):
            operand2 = factor()
            if token in ["*", "/"]:
                operand, operand3 = match_11()
                print(string.format(str(instr), operand, operand2, operand3, temporary[ts]))
                operand3 = temporary[ts]
                ts += 1
                instr += 1
                return operation, operand3
            return operation, operand2


def match_12():
    is_array = False
    if token in ["("]:
        match("(")
        args()
        match(")")
    else:
        is_array = match_8()
    return is_array


def match_13():
    if token in [","]:
        match(",")
        if token in ["("] or is_ID(token) or is_NUM(token):
            expression()
            if token in [","]:
                match_13()


generator(tokenlist)
